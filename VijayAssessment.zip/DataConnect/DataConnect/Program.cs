﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Data;

using System.Data.SqlClient;



namespace DataConnect
{

    class Program
    {

        static void Main(string[] args)
        {
          
            SqlConnection con = new SqlConnection(DataConnect.Properties.Settings.Default.KnifEdge);

            SqlDataReader reader;
            SqlDataReader reader1;
    

            try
            {

              
                con.Open();

                Console.WriteLine("List Of Top 10 Records From employees table ");

             reader = new SqlCommand("select top 10 * from Employies", con).ExecuteReader();

                int Counter=1;

                if (reader.HasRows)
                {
                    Console.WriteLine("No| Emp Num |     BirthDate     | FirstName |Last Name|Gender|     Hiredate\n------------------------------------------------------------------------------------");
                    while (reader.Read())                                                                                 
                    {

                        Console.WriteLine("{6} | {0}  |{1}|   {2}  | {3} |  {4}   |{5} ", reader.GetInt32(0),

                         reader.GetDateTime(1), reader.GetString(2), reader.GetString(3), reader.GetString(4), reader.GetDateTime(5), Counter);
                      Counter++;

                    }
                   // Console.ReadLine();

                    con.Close();
                }

                else
                {

                    Console.WriteLine("No rows found.");
                    //Console.ReadLine();

                }

                reader.Close();

            }

            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
               // Console.ReadLine();

            }  


            try
            {


                con.Open();

                Console.WriteLine("Enter The Page Number You wish to see ");
                int pageNo = Convert.ToInt32(Console.ReadLine());

                reader1 = new SqlCommand("select  * from Employies ORDER BY emp_no asc offset "+(pageNo-1)*5+" rows fetch next 5 Rows Only", con).ExecuteReader();

                int Counter = 1;

                if (reader1.HasRows)
                {
                    Console.WriteLine("No| Emp Num |     BirthDate     | FirstName |Last Name|Gender|     Hiredate\n------------------------------------------------------------------------------------");
                    while (reader1.Read())
                    {

                        Console.WriteLine("{6} | {0}  |{1}|   {2}  | {3} |  {4}   |{5} ", reader1.GetInt32(0),

                         reader1.GetDateTime(1), reader1.GetString(2), reader1.GetString(3), reader1.GetString(4), reader1.GetDateTime(5), Counter);
                        Counter++;

                    }
                    Console.ReadLine();

                }

                else
                {

                    Console.WriteLine("No rows found.");
                    Console.ReadLine();

                }

                reader1.Close();

            }

            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                Console.ReadLine();

            }


        }

    }

}