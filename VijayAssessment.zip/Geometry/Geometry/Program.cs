﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Geometry
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle cir = new Circle(5);
            cir.CalculateArea();
            Console.ReadLine(); 

            int shape = 0;

            Console.WriteLine("Select Geometric Shape On Which you perform operations");
            Console.WriteLine("1.Circle");
            Console.WriteLine("2.Rectangle");
            Console.WriteLine("3.Triangle");
            shape = Convert.ToInt32(Console.ReadLine());

           
        }
    }
}
