﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Geometry
{
    class Rectangle : IShapes
    {
        double bredth = 1;
        double area = 1;
        double length = 1;

        public Rectangle(double length, double bredth)
        {
            this.length = length;
            this.bredth = bredth; 
        }

        public void setLength(double length)
        {
            this.length = length;
        }

        public void setBredth(double bredth)
        {
            this.bredth = bredth;
        }

        public void CalculateArea()
        {
            area =length * bredth;
            Console.WriteLine("The Area of The Rectangle is ==> " + area);
        }
    }
}
