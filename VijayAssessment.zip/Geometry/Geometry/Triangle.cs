﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Geometry
{
    public class Triangle : IShapes
    {
        double height = 1;
        double side1 = 1;
        double side2 = 1;
        double side3 = 1;
        double area=1;

        public Triangle(double height, double side1)
        {
            this.side1 = side1;
            this.height = height;
                
        }

        public void setHeight(double height)
        {
            this.height = height;
        }

        public void setBase(double side1)
        {
            this.side1 = side1;
        }

        public void CalculateArea()
        {
            area = 1/2* side1* height;
            Console.WriteLine("The Area of The Triangle is ==> " + area);
        }

        public void GetAllSides()
        {
            Console.WriteLine("The base of The Triangle is ==> " + side1);
            Console.WriteLine("The sides  of The Triangle are ==> "+side2+ " "+side3 );
            Console.WriteLine("The Height of The Triangle is ==> " + height);
        }

    }
}
