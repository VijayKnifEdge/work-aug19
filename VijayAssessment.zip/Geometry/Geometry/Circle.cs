﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Geometry
{
   public class Circle: ICircle
    {
       double radius = 1;
       double area = 1;
       double circumferance = 1;

       public Circle(double radius)
       {
           this.radius = radius;
       }
       public void setRadius(double radius)
       {
           this.radius = radius;
       }

       public void CalculateArea()
       {
           area = 2 * Math.PI * radius * radius;
           Console.WriteLine("The Area of The Circle is ==> "+area);
       }

       public void CalculateCircumferance()
       {
           circumferance = 2 * Math.PI * radius;
           Console.WriteLine("The Circumferance of The Circle is ==> " + circumferance);
       }
    }
}
