﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            int n=16;
            Console.WriteLine("Enter a Number Between 16 And 1000");
            try
            {
                n = Convert.ToInt32(Console.ReadLine());
            }

            catch
            {
                Console.WriteLine("Invalid Input!!!");
                Console.ReadLine();
                System.Environment.Exit(0); 
            }

            if (n < 16 || n > 1000)
            {
                Console.WriteLine("Input is Not in the given range");
                Console.ReadLine();
            }
            else
            {
                for (int index = 1; index <= n; index++)
                {
                    if (index % 3 == 0 && index % 5 != 0)
                        Console.WriteLine("Fizz");
                    else if (index % 3 != 0 && index % 5 == 0)
                        Console.WriteLine("Buzz");
                    else if (index % 3 == 0 && index % 5 == 0)
                        Console.WriteLine("FizzBuzz");
                    else
                        Console.WriteLine(index);

                }
                Console.ReadLine();
            }
        }
    }
}
